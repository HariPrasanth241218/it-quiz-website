// FULL QUESTION BANK (ALL SUBJECTS)
const allQuestions = [
    // -------- DBMS --------
    {
        subject: "DBMS",
        question: "What does DBMS stand for?",
        options: [
            "Data Backup System",
            "Database Management System",
            "Data Block Management System",
            "Digital Base Management Software"
        ],
        answer: 1
    },
    {
        subject: "DBMS",
        question: "Which language is used to query databases?",
        options: ["HTML", "SQL", "C++", "Python"],
        answer: 1
    },
    {
        subject: "DBMS",
        question: "Which key uniquely identifies a record?",
        options: ["Foreign Key", "Primary Key", "Composite Key", "Candidate Key"],
        answer: 1
    },

    // -------- C --------
    {
        subject: "C",
        question: "Who developed C language?",
        options: ["Dennis Ritchie", "James Gosling", "Bjarne Stroustrup", "Guido van Rossum"],
        answer: 0
    },
    {
        subject: "C",
        question: "Which is a valid C data type?",
        options: ["int", "real", "float64", "number"],
        answer: 0
    },
    {
        subject: "C",
        question: "Which symbol is used for comments in C?",
        options: ["//", "#", "/* */", "<!-- -->"],
        answer: 2
    },

    // -------- OS --------
    {
        subject: "OS",
        question: "What does OS stand for?",
        options: ["Operating System", "Open Software", "Output System", "Order System"],
        answer: 0
    },
    {
        subject: "OS",
        question: "Which is not an operating system?",
        options: ["Windows", "Linux", "Oracle", "Mac OS"],
        answer: 2
    },
    {
        subject: "OS",
        question: "Which OS is open source?",
        options: ["Windows", "Linux", "DOS", "Mac OS"],
        answer: 1
    }
];

// VARIABLES (SAME LOGIC)
let questions = [];
let selectedSubject = "";
let current = 0;
let score = 0;
let userAnswers = [];

// SUBJECT SELECTION
function selectSubject(sub) {
    selectedSubject = sub;
    document.getElementById("selectedSubject").innerText =
        "Selected Subject: " + sub;
}

// START QUIZ
function startQuiz() {
    if (selectedSubject === "") {
        alert("Please select a subject");
        return;
    }

    // FILTER QUESTIONS BY SUBJECT
    questions = allQuestions.filter(q => q.subject === selectedSubject);

    current = 0;
    score = 0;
    userAnswers = [];

    document.getElementById("start").style.display = "none";
    document.getElementById("quiz").style.display = "block";
    showQuestion();
}

// SHOW QUESTION
function showQuestion() {
    let q = questions[current];
    document.getElementById("question").innerText = q.question;

    let html = "";
    q.options.forEach((opt, i) => {
        html += `<input type="radio" name="opt" value="${i}"> ${opt}<br>`;
    });

    document.getElementById("options").innerHTML = html;
}

// NEXT QUESTION
function nextQuestion() {
    let selected = document.querySelector('input[name="opt"]:checked');
    if (!selected) {
        alert("Please select an option");
        return;
    }

    let ans = parseInt(selected.value);
    userAnswers.push(ans);

    if (ans === questions[current].answer) {
        score++;
    }

    current++;
    if (current < questions.length) {
        showQuestion();
    } else {
        showResult();
    }
}

// SHOW RESULT
function showResult() {
    document.getElementById("quiz").style.display = "none";

    let html = `<h2>Subject: ${selectedSubject}</h2>`;
    html += `<h3>Your Score: ${score}/${questions.length}</h3>`;

    questions.forEach((q, i) => {
        if (userAnswers[i] !== q.answer) {
            html += `<p>
                <b>Question:</b> ${q.question}<br>
                <b>Correct Answer:</b> ${q.options[q.answer]}
            </p>`;
        }
    });

    document.getElementById("result").innerHTML = html;
    document.getElementById("result").style.display = "block";
}
